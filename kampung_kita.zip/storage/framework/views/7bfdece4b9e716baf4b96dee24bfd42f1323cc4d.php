<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>


  <h2 style="margin-top: 70px; margin-bottom: 0px; font-size: 30px;" align="center">Hasil Penilaian Kampung Wisata</h2>
   <h2 style="margin-top: px; margin-bottom: 70px; font-size: 30px;" align="center"><?php echo e($identitas -> nama_kampung_wisata); ?></h2>
 
  <h1 style="text-align: left; font-size: 21px;">Profil Kampung Wisata</h1>
  <table style="text-align: left; font-size: 19px;" >
    <tr>
      <td width="20%" style="vertical-align: top;">Nama Kampung Wisata</td>
      <td width="2%" style="vertical-align: top;">:</td>
      <td width="88%" style="vertical-align: top;"><?php echo e($identitas -> nama_kampung_wisata); ?></td>
    </tr>

     <tr>
      <td style="vertical-align: top;">Provinsi</td>
      <td style="vertical-align: top;">:</td>
      <td style="vertical-align: top;"><?php echo e($identitas -> provinsi); ?></td>
    </tr>

    <tr>
      <td style="vertical-align: top;">Kabupaten / Kota</td>
      <td style="vertical-align: top;">:</td>
      <td align="justify"><?php echo e($identitas -> kabupaten_kota); ?></td>
    </tr>

    <tr>
      <td style="vertical-align: top;">Kecamatan</td>
      <td style="vertical-align: top;">:</td>
      <td style="vertical-align: top;"><?php echo e($identitas -> kecamatan); ?></td>
    </tr> 

    <tr>
      <td style="vertical-align: top;">Kelurahan / Desa</td>
      <td style="vertical-align: top;">:</td>
      <td style="vertical-align: top;"><?php echo e($identitas -> kelurahan_desa); ?></td>
    </tr> 

    <tr>
      <td height="50px"></td>
    </tr>
  </table>
  <br>
  

  <h1 style="text-align: left; font-size: 25px; margin-bottom: -20px;">Penilaian Produk dan Layanan</h1> <br>

  <h1 style="text-align: left; font-size: 21px;">Produk Alam</h1>
  <table style="text-align: left; font-size: 19px;" >
  <?php $__currentLoopData = $daftarPenilaianAlam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td width="20%" style="vertical-align: top;">Nama Produk Alam</td>
      <td width="2%" style="vertical-align: top;">:</td>
      <td width="88%" style="vertical-align: top;"><?php echo e($alam -> nama_aspek); ?></td>
    </tr>

     <tr>
      <td style="vertical-align: top;">Permasalahan</td>
      <td style="vertical-align: top;">:</td>
      <td style="vertical-align: top;"><?php echo e($alam -> permasalahan); ?></td>
    </tr>

    <tr>
      <td style="vertical-align: top;">Keterangan</td>
      <td style="vertical-align: top;">:</td>
      <td align="justify"><?php echo e($alam -> keterangan); ?></td>
    </tr>

    <tr>
      <td style="vertical-align: top;">Tanggal Perbaikan</td>
      <td style="vertical-align: top;">:</td>
      <td style="vertical-align: top;"><?php echo e($alam -> tanggal_perbaikan); ?></td>
    </tr> 

    <tr>
      <td height="50px"></td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <br>


  <h1 style="text-align: left; font-size: 21px;">Produk Budaya</h1>
  <table style="text-align: left; font-size: 19px;" >
  <?php $__currentLoopData = $daftarPenilaianBudaya; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td width="20%" style="vertical-align: top;">Nama Produk Alam</td>
      <td width="2%" style="vertical-align: top;">:</td>
      <td width="88%" style="vertical-align: top;"><?php echo e($alam -> nama_aspek); ?></td>
    </tr>

     <tr>
      <td style="vertical-align: top;">Permasalahan</td>
      <td style="vertical-align: top;">:</td>
      <td style="vertical-align: top;"><?php echo e($alam -> permasalahan); ?></td>
    </tr>

    <tr>
      <td style="vertical-align: top;">Keterangan</td>
      <td style="vertical-align: top;">:</td>
      <td align="justify"><?php echo e($alam -> keterangan); ?></td>
    </tr>

    <tr>
      <td style="vertical-align: top;">Tanggal Perbaikan</td>
      <td style="vertical-align: top;">:</td>
      <td style="vertical-align: top;"><?php echo e($alam -> tanggal_perbaikan); ?></td>
    </tr> 

    <tr>
      <td height="50px"></td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <br>



  <h1 style="text-align: left; font-size: 21px;">Produk Buatan</h1>
  <table style="text-align: left; font-size: 19px;" >
  <?php $__currentLoopData = $daftarPenilaianBuatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td width="20%" style="vertical-align: top;">Nama Produk Alam</td>
      <td width="2%" style="vertical-align: top;">:</td>
      <td width="88%" style="vertical-align: top;"><?php echo e($alam -> nama_aspek); ?></td>
    </tr>

     <tr>
      <td style="vertical-align: top;">Permasalahan</td>
      <td style="vertical-align: top;">:</td>
      <td style="vertical-align: top;"><?php echo e($alam -> permasalahan); ?></td>
    </tr>

    <tr>
      <td style="vertical-align: top;">Keterangan</td>
      <td style="vertical-align: top;">:</td>
      <td align="justify"><?php echo e($alam -> keterangan); ?></td>
    </tr>

    <tr>
      <td style="vertical-align: top;">Tanggal Perbaikan</td>
      <td style="vertical-align: top;">:</td>
      <td style="vertical-align: top;"><?php echo e($alam -> tanggal_perbaikan); ?></td>
    </tr> 

    <tr>
      <td height="50px"></td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <br>


  <h1 style="text-align: left; font-size: 21px;">Fasilitas</h1>
  <table style="text-align: left; font-size: 19px;" >
  <?php $__currentLoopData = $daftarPenilaianFasilitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td width="20%" style="vertical-align: top;">Nama Produk Alam</td>
      <td width="2%" style="vertical-align: top;">:</td>
      <td width="88%" style="vertical-align: top;"><?php echo e($alam -> nama_aspek); ?></td>
    </tr>

     <tr>
      <td style="vertical-align: top;">Permasalahan</td>
      <td style="vertical-align: top;">:</td>
      <td style="vertical-align: top;"><?php echo e($alam -> permasalahan); ?></td>
    </tr>

    <tr>
      <td style="vertical-align: top;">Keterangan</td>
      <td style="vertical-align: top;">:</td>
      <td align="justify"><?php echo e($alam -> keterangan); ?></td>
    </tr>

    <tr>
      <td style="vertical-align: top;">Tanggal Perbaikan</td>
      <td style="vertical-align: top;">:</td>
      <td style="vertical-align: top;"><?php echo e($alam -> tanggal_perbaikan); ?></td>
    </tr> 

    <tr>
      <td height="50px"></td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <br>




  <h1 style="text-align: left; font-size: 21px;">Layanan</h1>
  <table style="text-align: left; font-size: 19px;" >
  <?php $__currentLoopData = $daftarPenilaianLayanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td width="20%" style="vertical-align: top;">Nama Produk Alam</td>
      <td width="2%" style="vertical-align: top;">:</td>
      <td width="88%" style="vertical-align: top;"><?php echo e($alam -> nama_aspek); ?></td>
    </tr>

     <tr>
      <td style="vertical-align: top;">Permasalahan</td>
      <td style="vertical-align: top;">:</td>
      <td style="vertical-align: top;"><?php echo e($alam -> permasalahan); ?></td>
    </tr>

    <tr>
      <td style="vertical-align: top;">Keterangan</td>
      <td style="vertical-align: top;">:</td>
      <td align="justify"><?php echo e($alam -> keterangan); ?></td>
    </tr>

    <tr>
      <td style="vertical-align: top;">Tanggal Perbaikan</td>
      <td style="vertical-align: top;">:</td>
      <td style="vertical-align: top;"><?php echo e($alam -> tanggal_perbaikan); ?></td>
    </tr> 

    <tr>
      <td height="50px"></td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <br>




  <h1 style="text-align: left; font-size: 25px;">Penilaian Pengelolaan</h1>
  <table style="text-align: left; font-size: 19px;" >
  <?php $__currentLoopData = $daftarPenilaianPengelolaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td width="20%" style="vertical-align: top;">Nama Produk Alam</td>
      <td width="2%" style="vertical-align: top;">:</td>
      <td width="88%" style="vertical-align: top;"><?php echo e($alam -> nama_aspek); ?></td>
    </tr>

     <tr>
      <td style="vertical-align: top;">Permasalahan</td>
      <td style="vertical-align: top;">:</td>
      <td style="vertical-align: top;"><?php echo e($alam -> permasalahan); ?></td>
    </tr>

    <tr>
      <td style="vertical-align: top;">Keterangan</td>
      <td style="vertical-align: top;">:</td>
      <td align="justify"><?php echo e($alam -> keterangan); ?></td>
    </tr>

    <tr>
      <td style="vertical-align: top;">Tanggal Perbaikan</td>
      <td style="vertical-align: top;">:</td>
      <td style="vertical-align: top;"><?php echo e($alam -> tanggal_perbaikan); ?></td>
    </tr> 

    <tr>
      <td height="50px"></td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <br>



  <h1 style="text-align: left; font-size: 21px;">Hasil Penilaian</h1>
  <table style="text-align: left; font-size: 19px;" >
    <tr>
      <td width="20%" style="vertical-align: top;">Nilai Produk</td>
      <td width="2%" style="vertical-align: top;">:</td>
      <td width="88%" style="vertical-align: top;"><?php echo e($alam -> nilai_produk); ?></td>
    </tr>

     <tr>
      <td style="vertical-align: top;">Nilai Layanan</td>
      <td style="vertical-align: top;">:</td>
      <td style="vertical-align: top;"><?php echo e($alam -> nilai_layanan); ?></td>
    </tr>

    <tr>
      <td style="vertical-align: top;">Nilai Pengelolaan</td>
      <td style="vertical-align: top;">:</td>
      <td align="justify"><?php echo e($alam -> nilai_pengelolaan); ?></td>
    </tr>

    <tr>
      <td style="vertical-align: top;">Hasil Penilaian</td>
      <td style="vertical-align: top;">:</td>
      <td style="vertical-align: top;"><?php echo e($alam -> hasil_penilaian); ?></td>
    </tr> 

    <tr>
      <td height="50px"></td>
    </tr>
  </table>
  <br>




 

</body>
</html><?php /**PATH C:\xampp\htdocs\kampung_kita\resources\views/cetakHasilPenilaian.blade.php ENDPATH**/ ?>